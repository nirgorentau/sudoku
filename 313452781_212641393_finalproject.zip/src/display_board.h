#ifndef DISPLAY_BOARD_H
#define DISPLAY_BOARD_H
#include <stdio.h>
#include "board.h"

/* Print the board to stdout */
void display_board(Board* board);

#endif